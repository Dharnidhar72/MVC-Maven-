package calc;

public abstract class Variables {
	int first_num;
	int second_num;
	
	Variables(int first_num,int second_num){
		this.first_num = first_num;
		this.second_num = second_num;
	}

}
